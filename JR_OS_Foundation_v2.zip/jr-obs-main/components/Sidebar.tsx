"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bot,
  BriefcaseBusiness,
  Building2,
  ClipboardCheck,
  FileText,
  Gauge,
  HardHat,
  Package,
  ReceiptText,
  Settings,
  Users,
  WalletCards,
} from "lucide-react";

const menuItems = [
  { label: "Dashboard", href: "/", icon: Gauge },
  { label: "Customers", href: "/customers", icon: Users },
  { label: "Builders", href: "/builders", icon: Building2 },
  { label: "Jobs", href: "/jobs", icon: BriefcaseBusiness },
  { label: "Quotes", href: "/quotes", icon: FileText },
  { label: "Estimates", href: "/estimates", icon: WalletCards },
  { label: "Invoices", href: "/invoices", icon: ReceiptText },
  { label: "Materials", href: "/materials", icon: Package },
  { label: "Surveys", href: "/surveys", icon: ClipboardCheck },
  { label: "Job Packs", href: "/job-packs", icon: HardHat },
  { label: "JR AI", href: "/ai", icon: Bot },
  { label: "Business", href: "/business", icon: Gauge },
  { label: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <>
      <aside className="hidden w-72 shrink-0 border-r border-slate-800 bg-slate-950 p-5 lg:block">
        <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/5 p-4">
          <p className="text-xl font-black tracking-tight text-white">JR OS</p>
          <p className="mt-1 text-xs text-slate-400">JR Electrical Business Suite</p>
        </div>
        <nav className="mt-6 space-y-1">
          {menuItems.map(({ label, href, icon: Icon }) => {
            const active = pathname === href;
            return (
              <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${active ? "bg-cyan-500 text-slate-950" : "text-slate-300 hover:bg-slate-900 hover:text-white"}`}>
                <Icon size={18} />
                {label}
              </Link>
            );
          })}
        </nav>
      </aside>
      <nav className="fixed inset-x-0 bottom-0 z-50 flex items-center justify-around border-t border-slate-800 bg-slate-950/95 px-2 py-2 backdrop-blur lg:hidden">
        {menuItems.slice(0, 5).map(({ label, href, icon: Icon }) => {
          const active = pathname === href;
          return (
            <Link key={href} href={href} className={`flex min-w-14 flex-col items-center gap-1 rounded-lg px-2 py-1 text-[10px] ${active ? "text-cyan-400" : "text-slate-400"}`}>
              <Icon size={19} />
              {label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
