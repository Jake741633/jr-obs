import PageHeader from "@/components/ui/PageHeader";

export default function ComingSoonPage({ eyebrow, title, description, features }: { eyebrow: string; title: string; description: string; features: string[] }) {
  return <main className="min-h-screen p-5 sm:p-8"><PageHeader eyebrow={eyebrow} title={title} description={description}/><div className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/70 p-5"><p className="text-sm font-semibold text-cyan-400">Next build stage</p><div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{features.map((feature)=><div key={feature} className="rounded-xl border border-slate-800 bg-slate-950 p-4 text-sm text-slate-300">{feature}</div>)}</div></div></main>;
}
