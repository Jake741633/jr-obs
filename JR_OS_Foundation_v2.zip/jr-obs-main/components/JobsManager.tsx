"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { Plus, Search, Trash2, X } from "lucide-react";
import type { Job, JobStatus } from "@/types/job";
import { sampleJobs } from "@/data/sampleJobs";
import StatCard from "@/components/ui/StatCard";

const STORAGE_KEY = "jr-os-jobs-v1";
const statuses: JobStatus[] = ["Enquiry", "Survey Booked", "Quoted", "Accepted", "In Progress", "Completed", "Invoiced", "Paid"];

export default function JobsManager() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [ready, setReady] = useState(false);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => { const saved = localStorage.getItem(STORAGE_KEY); setJobs(saved ? JSON.parse(saved) : sampleJobs); setReady(true); }, []);
  useEffect(() => { if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(jobs)); }, [jobs, ready]);
  const filtered = useMemo(() => jobs.filter((job) => `${job.title} ${job.address} ${job.status}`.toLowerCase().includes(query.toLowerCase())), [jobs, query]);

  function addJob(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget);
    const job: Job = { id: crypto.randomUUID(), customerId: String(form.get("customerId") || "unassigned"), title: String(form.get("title") || "").trim(), address: String(form.get("address") || "").trim(), status: String(form.get("status") || "Enquiry") as JobStatus, description: String(form.get("description") || "").trim() || undefined, startDate: String(form.get("startDate") || "") || undefined, estimatedLabour: Number(form.get("estimatedLabour")) || undefined, createdAt: new Date().toISOString() };
    if (!job.title || !job.address) return; setJobs((current) => [job, ...current]); event.currentTarget.reset(); setOpen(false);
  }

  function updateStatus(id: string, status: JobStatus) { setJobs((current) => current.map((job) => job.id === id ? { ...job, status } : job)); }

  return <>
    <div className="mt-6 grid gap-4 sm:grid-cols-3"><StatCard label="Active jobs" value={jobs.filter((j) => !["Completed", "Paid"].includes(j.status)).length} /><StatCard label="In progress" value={jobs.filter((j) => j.status === "In Progress").length} /><StatCard label="Completed / paid" value={jobs.filter((j) => ["Completed", "Paid"].includes(j.status)).length} /></div>
    <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/70">
      <div className="flex flex-col gap-3 border-b border-slate-800 p-4 sm:flex-row sm:items-center sm:justify-between"><div className="relative max-w-md flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18}/><input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search jobs..." className="w-full rounded-xl border border-slate-700 bg-slate-950 py-2.5 pl-10 pr-3 text-sm outline-none focus:border-cyan-500"/></div><button onClick={()=>setOpen(true)} className="flex items-center justify-center gap-2 rounded-xl bg-cyan-500 px-4 py-2.5 text-sm font-bold text-slate-950"><Plus size={18}/> Create job</button></div>
      <div className="divide-y divide-slate-800">{!ready ? <p className="p-5 text-slate-400">Loading jobs…</p> : null}{ready && !filtered.length ? <p className="p-5 text-slate-400">No jobs found.</p> : null}{filtered.map((job)=><div key={job.id} className="flex flex-col gap-4 p-5 lg:flex-row lg:items-center lg:justify-between"><div><h3 className="font-bold">{job.title}</h3><p className="mt-1 text-sm text-slate-400">{job.address}</p>{job.description ? <p className="mt-2 max-w-2xl text-sm text-slate-500">{job.description}</p>:null}</div><div className="flex items-center gap-2"><select value={job.status} onChange={(e)=>updateStatus(job.id,e.target.value as JobStatus)} className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm outline-none focus:border-cyan-500">{statuses.map((status)=><option key={status}>{status}</option>)}</select><button onClick={()=>setJobs((current)=>current.filter((item)=>item.id!==job.id))} className="rounded-lg p-2 text-slate-500 hover:bg-red-500/10 hover:text-red-400"><Trash2 size={18}/></button></div></div>)}</div>
    </div>
    {open ? <div className="fixed inset-0 z-[60] flex items-end justify-center bg-slate-950/80 backdrop-blur-sm sm:items-center sm:p-6"><form onSubmit={addJob} className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl border border-slate-700 bg-slate-900 p-5 sm:rounded-2xl"><div className="flex justify-between"><div><h2 className="text-xl font-bold">Create job</h2><p className="mt-1 text-sm text-slate-400">Start with the basic job information.</p></div><button type="button" onClick={()=>setOpen(false)} className="rounded-lg p-2 text-slate-400"><X/></button></div><div className="mt-5 grid gap-4 sm:grid-cols-2"><JobField label="Job title *" name="title" required/><JobField label="Customer ID / name" name="customerId"/><div className="sm:col-span-2"><JobField label="Site address *" name="address" required/></div><label className="text-sm text-slate-300">Status<select name="status" className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5">{statuses.map((s)=><option key={s}>{s}</option>)}</select></label><JobField label="Start date" name="startDate" type="date"/><JobField label="Estimated labour (£)" name="estimatedLabour" type="number"/><label className="text-sm text-slate-300 sm:col-span-2">Description<textarea name="description" rows={3} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5"/></label></div><div className="mt-6 flex justify-end gap-3"><button type="button" onClick={()=>setOpen(false)} className="rounded-xl border border-slate-700 px-4 py-2.5">Cancel</button><button className="rounded-xl bg-cyan-500 px-5 py-2.5 font-bold text-slate-950">Save job</button></div></form></div>:null}
  </>;
}
function JobField({label,name,type="text",required=false}:{label:string;name:string;type?:string;required?:boolean}){return <label className="text-sm text-slate-300">{label}<input name={name} type={type} required={required} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 outline-none focus:border-cyan-500"/></label>}
