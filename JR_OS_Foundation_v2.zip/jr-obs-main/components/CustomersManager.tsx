"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { Plus, Search, Trash2, X } from "lucide-react";
import type { Customer, PreferredContact } from "@/types/customer";
import { sampleCustomers } from "@/data/sampleCustomers";
import StatCard from "@/components/ui/StatCard";

const STORAGE_KEY = "jr-os-customers-v1";

export default function CustomersManager() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [ready, setReady] = useState(false);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    setCustomers(saved ? JSON.parse(saved) : sampleCustomers);
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(customers));
  }, [customers, ready]);

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) return customers;
    return customers.filter((customer) => [customer.name, customer.company, customer.phone, customer.email, customer.address].some((value) => value?.toLowerCase().includes(q)));
  }, [customers, query]);

  function addCustomer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const customer: Customer = {
      id: crypto.randomUUID(),
      name: String(form.get("name") ?? "").trim(),
      company: String(form.get("company") ?? "").trim() || undefined,
      phone: String(form.get("phone") ?? "").trim() || undefined,
      email: String(form.get("email") ?? "").trim() || undefined,
      address: String(form.get("address") ?? "").trim() || undefined,
      preferredContact: String(form.get("preferredContact") ?? "WhatsApp") as PreferredContact,
      notes: String(form.get("notes") ?? "").trim() || undefined,
      createdAt: new Date().toISOString(),
    };
    if (!customer.name) return;
    setCustomers((current) => [customer, ...current]);
    event.currentTarget.reset();
    setOpen(false);
  }

  return (
    <>
      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <StatCard label="Total customers" value={customers.length} />
        <StatCard label="Preferred WhatsApp" value={customers.filter((c) => c.preferredContact === "WhatsApp").length} />
        <StatCard label="Companies / builders" value={customers.filter((c) => c.company).length} />
      </div>

      <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/70">
        <div className="flex flex-col gap-3 border-b border-slate-800 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative max-w-md flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search customers..." className="w-full rounded-xl border border-slate-700 bg-slate-950 py-2.5 pl-10 pr-3 text-sm outline-none focus:border-cyan-500" />
          </div>
          <button onClick={() => setOpen(true)} className="flex items-center justify-center gap-2 rounded-xl bg-cyan-500 px-4 py-2.5 text-sm font-bold text-slate-950 hover:bg-cyan-400"><Plus size={18} /> Add customer</button>
        </div>
        <div className="divide-y divide-slate-800">
          {!ready ? <p className="p-5 text-slate-400">Loading customers…</p> : null}
          {ready && filtered.length === 0 ? <p className="p-5 text-slate-400">No customers found.</p> : null}
          {filtered.map((customer) => (
            <div key={customer.id} className="flex flex-col gap-4 p-5 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2"><h3 className="font-bold text-white">{customer.name}</h3>{customer.company ? <span className="rounded-full bg-slate-800 px-2 py-1 text-xs text-slate-300">{customer.company}</span> : null}</div>
                <p className="mt-1 text-sm text-slate-400">{customer.address || "No address added"}</p>
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-300"><span>{customer.phone || "No phone"}</span><span>{customer.email || "No email"}</span><span className="text-cyan-400">{customer.preferredContact}</span></div>
                {customer.notes ? <p className="mt-3 max-w-2xl text-sm text-slate-500">{customer.notes}</p> : null}
              </div>
              <button aria-label={`Delete ${customer.name}`} onClick={() => setCustomers((current) => current.filter((item) => item.id !== customer.id))} className="self-start rounded-lg p-2 text-slate-500 hover:bg-red-500/10 hover:text-red-400"><Trash2 size={18} /></button>
            </div>
          ))}
        </div>
      </div>

      {open ? (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-slate-950/80 p-0 backdrop-blur-sm sm:items-center sm:p-6">
          <form onSubmit={addCustomer} className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl border border-slate-700 bg-slate-900 p-5 shadow-2xl sm:rounded-2xl">
            <div className="flex items-center justify-between"><div><h2 className="text-xl font-bold">Add customer</h2><p className="mt-1 text-sm text-slate-400">Create a customer record for quotes, jobs and invoices.</p></div><button type="button" onClick={() => setOpen(false)} className="rounded-lg p-2 text-slate-400 hover:bg-slate-800"><X /></button></div>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <Field label="Customer name *" name="name" required />
              <Field label="Company / builder" name="company" />
              <Field label="Phone" name="phone" type="tel" />
              <Field label="Email" name="email" type="email" />
              <div className="sm:col-span-2"><Field label="Address" name="address" /></div>
              <label className="text-sm text-slate-300">Preferred contact<select name="preferredContact" defaultValue="WhatsApp" className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 outline-none focus:border-cyan-500"><option>WhatsApp</option><option>Phone</option><option>Email</option></select></label>
              <label className="text-sm text-slate-300 sm:col-span-2">Notes<textarea name="notes" rows={3} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 outline-none focus:border-cyan-500" /></label>
            </div>
            <div className="mt-6 flex justify-end gap-3"><button type="button" onClick={() => setOpen(false)} className="rounded-xl border border-slate-700 px-4 py-2.5 text-sm font-semibold">Cancel</button><button className="rounded-xl bg-cyan-500 px-5 py-2.5 text-sm font-bold text-slate-950">Save customer</button></div>
          </form>
        </div>
      ) : null}
    </>
  );
}

function Field({ label, name, type = "text", required = false }: { label: string; name: string; type?: string; required?: boolean }) {
  return <label className="text-sm text-slate-300">{label}<input name={name} type={type} required={required} className="mt-2 w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 outline-none focus:border-cyan-500" /></label>;
}
