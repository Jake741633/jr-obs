import type { Customer } from "@/types/customer";

export const sampleCustomers: Customer[] = [
  {
    id: "cust-001",
    name: "Example Customer",
    phone: "07700 900000",
    email: "customer@example.com",
    address: "Epsom, Surrey",
    preferredContact: "WhatsApp",
    notes: "Example record. Replace this with a real customer or delete it.",
    createdAt: "2026-07-29T12:00:00.000Z",
  },
];
