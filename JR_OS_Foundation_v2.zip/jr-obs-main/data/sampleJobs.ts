import type { Job } from "@/types/job";

export const sampleJobs: Job[] = [
  {
    id: "job-001",
    customerId: "cust-001",
    title: "Example electrical job",
    address: "Epsom, Surrey",
    status: "Enquiry",
    description: "Example job for testing JR OS.",
    createdAt: "2026-07-29T12:00:00.000Z",
  },
];
