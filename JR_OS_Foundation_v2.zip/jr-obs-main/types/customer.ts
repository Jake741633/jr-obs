export type PreferredContact = "Phone" | "Email" | "WhatsApp";

export type Customer = {
  id: string;
  name: string;
  company?: string;
  phone?: string;
  email?: string;
  address?: string;
  preferredContact: PreferredContact;
  notes?: string;
  createdAt: string;
};
