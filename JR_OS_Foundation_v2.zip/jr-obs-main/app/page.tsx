import Link from "next/link";
import { ArrowRight, BriefcaseBusiness, FilePlus2, UserPlus } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import StatCard from "@/components/ui/StatCard";

export default function Home() {
  return (
    <main className="min-h-screen p-5 sm:p-8">
      <PageHeader eyebrow="Owner Dashboard" title="Welcome back, Jake" description="Your command centre for enquiries, jobs, quotes, invoices and business growth." />
      <section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Today's jobs" value="0" detail="No jobs scheduled yet" />
        <StatCard label="Open quotes" value="0" detail="Quotes awaiting a decision" />
        <StatCard label="Unpaid invoices" value="£0.00" detail="Outstanding customer balance" />
        <StatCard label="Business readiness" value="Foundation" detail="Core system setup underway" />
      </section>
      <section className="mt-8 grid gap-6 xl:grid-cols-[1.3fr_1fr]">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5">
          <h2 className="text-xl font-bold">Quick actions</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            {[
              { href: "/customers", label: "Add customer", icon: UserPlus },
              { href: "/jobs", label: "Create job", icon: BriefcaseBusiness },
              { href: "/quotes", label: "New quote", icon: FilePlus2 },
            ].map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href} className="group rounded-xl border border-slate-800 bg-slate-950 p-4 transition hover:border-cyan-500/60">
                <Icon className="text-cyan-400" size={22} />
                <div className="mt-4 flex items-center justify-between font-semibold"><span>{label}</span><ArrowRight size={17} className="transition group-hover:translate-x-1" /></div>
              </Link>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-5">
          <p className="text-sm font-semibold text-amber-300">Build status</p>
          <h2 className="mt-2 text-xl font-bold">JR OS foundation is live</h2>
          <p className="mt-3 text-sm leading-6 text-slate-300">Customers and jobs now save on this device. Database syncing, quotes and invoicing will be connected in the next build stage.</p>
        </div>
      </section>
    </main>
  );
}
