import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Sales" title="Quotes" description="Build professional fixed-price or labour-only quotes with materials and terms." features={["Quote builder","Material markups","Labour allowances","PDF and email delivery","Acceptance tracking","Terms and exclusions"]}/>}
