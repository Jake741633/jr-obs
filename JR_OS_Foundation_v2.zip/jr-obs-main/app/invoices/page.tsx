import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Finance" title="Invoices" description="Create invoices, track payments and chase overdue balances." features={["Invoice builder","Payment details","Due dates and reminders","Paid / overdue tracking","PDF downloads","Quote-to-invoice conversion"]}/>}
