import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Performance" title="Business" description="See profitability, pipeline, workload and readiness to grow JR Electrical Services." features={["Revenue and profit","Pipeline value","PAYE transition readiness","Quote conversion","Customer sources","Business health score"]}/>}
