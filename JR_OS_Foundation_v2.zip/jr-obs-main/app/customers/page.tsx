import CustomersManager from "@/components/CustomersManager";
import PageHeader from "@/components/ui/PageHeader";

export default function CustomersPage() {
  return <main className="min-h-screen p-5 sm:p-8"><PageHeader eyebrow="Contacts" title="Customers" description="Keep customer details, preferred contact methods and notes ready for every job." /><CustomersManager /></main>;
}
