import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Assistant" title="JR AI" description="Use AI to turn site notes into jobs, quotes, reminders and recommendations." features={["Voice note to job","Quote drafting","Daily briefing","Warnings and follow-ups","Business coach","Smart recommendations"]}/>}
