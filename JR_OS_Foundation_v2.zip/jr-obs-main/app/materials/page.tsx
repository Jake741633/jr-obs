import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Purchasing" title="Materials" description="Build a reusable materials library with suppliers, costs and markups." features={["CEF, TLC and Screwfix links","Supplier stock codes","Favourite materials","Cost and sell price","Job material lists","Price history"]}/>}
