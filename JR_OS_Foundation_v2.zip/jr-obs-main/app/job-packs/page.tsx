import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Delivery" title="Job Packs" description="Keep scope, materials, drawings, RAMS, photos and certificates together." features={["Scope and programme","Material orders","RAMS and risk assessments","Site photos","Certificates","Electrician access controls"]}/>}
