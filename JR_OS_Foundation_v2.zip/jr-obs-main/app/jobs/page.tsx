import JobsManager from "@/components/JobsManager";
import PageHeader from "@/components/ui/PageHeader";
export default function JobsPage(){return <main className="min-h-screen p-5 sm:p-8"><PageHeader eyebrow="Work pipeline" title="Jobs" description="Track each job from first enquiry through to completion and payment."/><JobsManager/></main>}
