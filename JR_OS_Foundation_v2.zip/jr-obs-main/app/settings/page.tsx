import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Administration" title="Settings" description="Control business details, pricing, payment details, users and templates." features={["Business setup wizard","Logo and company details","Labour rates and markups","Payment settings","Terms templates","Users and permissions"]}/>}
