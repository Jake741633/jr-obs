import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Site workflow" title="Surveys" description="Capture site details, photos and requirements before pricing." features={["Domestic survey form","Commercial survey form","Photos and voice notes","Customer checklist","Turn survey into quote"]}/>}
