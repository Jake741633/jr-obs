import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Trade contacts" title="Builders" description="Manage repeat builders, contractors, contacts and work history." features={["Builder contact records","Linked jobs and quotes","Payment and pricing notes","Repeat-work performance"]}/>}
