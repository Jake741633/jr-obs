import ComingSoonPage from "@/components/ComingSoonPage";
export default function Page(){return <ComingSoonPage eyebrow="Sales" title="Estimates" description="Provide flexible estimates where the final scope or cost may change." features={["Estimate builder","Range and assumptions","Convert to quote","Customer approval"]}/>}
